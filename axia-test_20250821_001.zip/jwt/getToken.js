import jwt from "jsonwebtoken"

const getToken = async (userId) => {
return jwt.sign({userId}, process.env.SECRET_KEY, {expiresIn:"1h"})
}

export default getToken