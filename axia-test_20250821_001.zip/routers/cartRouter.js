import Router from "express";
import {
  createCartItem,
} from "../controllers/cartController.js";
import { authMiddleware } from "../middlewares/authMiddleware.js";

const cartRouter = Router();

cartRouter
  //create cart
  .post("/cart/create/:id", authMiddleware, createCartItem);

export default cartRouter;
