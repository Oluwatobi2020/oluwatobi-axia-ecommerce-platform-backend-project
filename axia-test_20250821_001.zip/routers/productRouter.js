import { Router } from "express";
import { createProduct } from "../controllers/productController.js";

import { authMiddleware } from "../middlewares/authMiddleware.js";

const productRouter = Router();

productRouter
  //post
  .post("/product/create", authMiddleware, createProduct);

export default productRouter
