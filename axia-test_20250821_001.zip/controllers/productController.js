import Product from "../schemas/productSchema.js"

export const createProduct = async (req, res) => {
  const { name, price, color, size } = req.body;

  const user = req.user;

  if (!name || !price || !color || !size) {
    res.status(400).json({ message: "Please provide all the required fields" });
    return;
  }
  try {
    const newProduct = new Product({ ...req.body, userId: user._id });
    await newProduct.save();
    res.status(201).json({ mess: "New Product created successfully" });
  } catch (error) {
    res.status(500).json(error);
  }
};

