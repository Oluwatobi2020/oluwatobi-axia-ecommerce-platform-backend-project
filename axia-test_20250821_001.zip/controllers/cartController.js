import Cart from "../schemas/cartSchema.js"
import Product from "../schemas/productSchema.js"

export const createCartItem = async (req, res) => {
  const user = req.user;
  const { incomingProdId } = req.params;

  try {
    const product = await Product.findById(incomingProdId);
    if (!product) {
      res.status(400).json({ message: "Product does not exist" });
      return;
    }
    const cart = await Cart.findOne({ userId: user._id });
    if (!cart) {
      const newCart = new Cart({
        userId: user._id,
        products: [{ productId: incomingProdId, quantity: 1 }],
      });
      await newCart.save();
    } else {
      const prodectIndex = Cart.products.findIndex(
        (item) => item.productId === incomingProdId
      );
      if (prodectIndex > -1) {
        Cart.products[prodectIndex].quantity++;
      } else {
        Cart.products.push({ productId: incomingProdId, quantity: 1 });
      }
      await cart.save();
    }
  } catch (error) {
    console.log(error);
  }
};

